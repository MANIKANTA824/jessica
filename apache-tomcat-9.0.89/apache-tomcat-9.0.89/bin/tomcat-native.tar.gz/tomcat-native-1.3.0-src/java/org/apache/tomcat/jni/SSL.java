/*
 *  Licensed to the Apache Software Foundation (ASF) under one or more
 *  contributor license agreements.  See the NOTICE file distributed with
 *       *l incark    @tu iSofMla pubTurkark    @l int SSL_Eative    L_SHUTDOWAPR/N offseERT_CHAa  */
      uc = 6;
    pu
stame Filename tlic .x /
    pubN offse2.x on        * callbpublicUTDose
stame Filename t      *nfo           0x Se abl);

    /*ic grt at a    TSCAPNam ltame Filename ttnd_Nam2 g   = 1ors the Nbal Passwordyte[] b addit incal information regapr_cmdis f_ i  um0.1
   gets(b   static fisy wh      vokeTSCAP begLL: eted count.
     * @param ssl SAPR_SHELLCMative
     * su   s  vokeTSCAP begLL: di  cRpu,253    *  ptio eted count.
     * @param ssl SAPR_PROGRAM Bitwise-OR of    s  vokeTSCAP begLL:,
rt tatic 
   urption;

    /eted count.
     * @param ssl SAPR_PROGRAM_ENVif all SSL_   saradP begLL: t aPATH,stati urption;

    /eted count.
     * @param ssl SAPR_PROGRAM_PATH * @deprec   static fisy wh      vokeTSCAP begLL:,
rt tatic 
   urption;

    /eted count.
     * @param ssl SAPR_SHELLCMD_ENVi
    information regapr_wait_how_ i  um0.1
   gets(b   swaite Software Foundedn the speeturnn  //eted count.
     * @param ssl SAPR_WAITve
     * su   sdo25303waite-- j * @  *

  i     =rnn  /plication protocol)
     * the worAPR_NOWAITv int SSL_INFtion regapr_exit_why_ i  um0.1
   gets(b   s the speexit
    ing tmpeted count.
     * @param ssl SAPR_PROC_EXITop Bitwise-OR of    s the speexit
  du     a0signm seted count.
     * @param ssl SAPR_PROC_SIGinal int  all SSL_   s the speexit
  .
   ump
  .   re availeted count.
     * @param ssl SAPR_PROC_SIGina_COREi
    inforprotocol)
     * the worAPR_NO_PIPEnative
     * supports that flag.</i>
  APR_FULL    puitwise-OR of all SSL_OP_* to test.
  APR_FULL NON   pui all SSL_OP_* are supported by OpAPR_PAR* re   puit* @deprecated Unused. Will be remAPR_CHILD    puitw
    inforprotocol)
     * the worAPR_LIMIT_CPUtive
     * supports that flag.</i>
  APR_LIMIT_Me currese-OR of all SSL_OP_* to test.
  APR_LIMIT_NPROC if all SSL_OP_* are supported by OpAPR_LIMIT_NONT     = 0x0 SSL_   schild    =dded,    pur56 * @ng pounnatiLE_ECDt */
eted count.
     * @param ssl SAPR_OC_REASO   pATH tive
     * su   sS   i_fd1i e aS        eted count.
     * @param ssl SAPR_OC_REASO  UN    ABLEise-OR of    blic statir);

rle tihe ope      or   t .
225ee spCHAacusedup (bpubliHedt%2snNfisrandom are Foum ssignm s     ild
    public static final int SSL_INFO_APR_OC_REASO  RE static f all SSL_   public stnnatiLE_EC   =been    pub,sdo2whswoD_SHUs25ee spCHAa(bpubliHedt%2snNfikimentati  ild
    public static final int SSL_INFO_APR_OC_REASO  UNREGISTic fi@deprec   s   phowntati  ildeexit
      ou03 0aknAPdom     bugg   s?ublic static final int SSL_INFO_APR_OC_REASO  LOST
    public stat   blic statihealtc fieool tihe ope     f
    s    *ic n     rify depsL_OP_NETSCatiia>
  o-op.    public static final int SSL_INFO_APR_OC_REASO  RUNNAT_ENGINE5public staapr_kime_.
  s of t_ i  umrites a  gets(b   s the speUs25evlenam pme
22signm sublic static final int SSL_INFO_APR_KILL NEnt SSL_OP_NETS0;ets(b   s the speUs2am pmSIGKILL     pr_e bo_tacusedup blic static final int SSL_INFO_APR_KILL ALWAYSop Bitwise-OR of    sSIGTicM,3waite3ile.
  m,mSIGKILL blic static final int SSL_INFO_APR_KILL AFTic_TIME     all SSL_   swaite Soevlen Softwar the speetuted
     blic static final int SSL_INFO_APR_JUST_WAITve
*
     * @deprec   s eFO_SIGTicMeys.
     waiteblic static final int SSL_INFO_APR_KILL ONLY
     */
 
    inforprotocol)
     * the worAPR_PROC_DETACH @DeEGROUNDETS0;c   sDo25303dettrileted count.
     * @param ssl SAPR_PROC_DETACH DAEMONpublise-Oc   sDettrileteblic staMaximumx    */
   argutInfoHE_SERV9.7.  the speng poeted count.
     * @param ssl SMAX_ARGS_ public statiise-02ic stat  aMaximumx    */
   tion;

    /**
     oHE_SERV9.7.  the speng poeted count.
     * @param ssl SMAX_ENV_ public statiiise-02ic ve was not compillloD = 1 pr_ethe_ta   uct SSLfroth of lag (0 ... veHER_CHAa   pr rify depialize new BIO
  ol Sandom sequence in bytes
    *         int SSL_Sotceates random data to filena_new
alwac      =ol oved in Tomcat 10.1.. veHER native in   * n
    n-ive      ng poiename.NT_DH_Bexecu= sTSCAPE_Caa
    CACHunixHE_SkIOCallback callbaincaTCAPresulc 
   the spemat
  ialize new BIO
  ol Sandom sequence in bytes
    *   APR_INCHILDn Softwar  ild,eys.
APR_INPAR* rn Softwar ar   lly
        de> if ly suppo/OR_WANT_CONNECT     = 7;
 arouE_Sk      []  the  boole=ol oved in Tomcat 10.1C.9.7. */
    the speys.
execu=  */
    thgLL:     
    at  the spflag (0 ... verify dept    tis)    ou03waitmani*/
packa
    the spen Tomrmi0008;public stati pr_ethe_waite SoftwatIOCallback callbaincaTCAP the spemat
  OCallback callbaingd. WiTCAP begLL: n Tru/t%2snNfinaALL: argsiTCAPargutInfoH 0x asic nate a
    thgLL:.Eativefir uoid setPPPPPPPPPPPPP  */blic statiSCAP begLL: ccessful
   rt OFF andvative
   tion;

    /t * @r*/
packa
    the sp.NT_DH_oid setPPPPPPPPPPPPblic statia liLE
   NULL-omrmi0008d_SERVERs.... veargutInfoid setPPPPPPPPPPPP veHg  i staticAPR_PROGRAM_ENV,SAPR_PROGRAM_PATH,  contd setPPPPPPPPPPPPAPR_SHELLCMD_ENViis f
    SL_O    sful
   rt OFF aattraTCAP theattraw*/blic sttatico3detmrmi0e howntoERV9.7. acka
  unsafe leghe sp len The length of random sequence in bytes
    *   TCAPresulc 
   the spemat
  ialize n/OR_WANT_CONNECT     = 7;
 arouRV9.7. nativethe  tatus coingd. W* @param filename Filename to save thetatus c[] args,etatus c[] tio* @param filename Filename to save the_new
attr  boolem seal statsUpublic staWaite Sofai  ilde the spen TddeOCallback callbaincaTCAP the spemat
     at   ronspo dic nate ades       ilde the spful
   rt OFF anxitanxit[0] TCAPreet the nxita_MY_LAST_Ptwar  ild,ed
     ilde the spful
   rrrrrrrrrrrrrrrrddes,eSoftwareignm s  at  a* Add ati  ilden Tdde.ful
   rrrrrrrrrrrrrrrrOn plat   ta>   pud.9.6dal int S    /**
  SCatii    tomcatSESS_CACHE_OFF = 0x0000;OOSE_MY_LASnt SSL_OPa  */
     et the ssPAPR_E, loMPd. Will banxit[1] Whyd ati  ildedded, ss.
  UnuseeSofof:e removedPRE>lag (0 .APR_PROC_EXITop Bitwie--  the spenmrmi0008d_  ing tmlag (0 .APR_PROC_SIGinal int e--  the spenumbkimeSd      eignm lag (0 .APR_PROC_SIGina_COREie--  the spenumbkimeSd      eignm ,  contd setPPPPPPPPPPPPPPPPPPPPPPPPPP   * @t
  .   re  umply suppord/PRE>lag (0 .SLn a laa   ow How blic stwelaa  .rrOnefof:e removedPRE>lag (0 .APR_WAITve
-- bwackHuntientati  ild  the speddes.lag (0 .APR_NOWAITv--    *   immedi inly-native        ifc final int ame Filename t  ild     tntp_VERStly suppord/PRE>lag (0 .S   *   TCAP  ildsE_MY_LAS* Retuubli Get ttryptc nateis  the sp.NTile tionefof:e removedPRE>lag (0 .APR_CHILD Dtic fina--   ild    no bool*/
runnHed.WN l intAPR_CHILD , lDtic f--   ild    Dt */
runnHed.WN l intd/PRE>lag (0  later secated Unused.WN l int SataL_new
ethe  int [] txit, int Sata owal statsUpublic staWaite Sofa
22blic sta  ilde the spen Tddeeys.
   *   i    tomcatTSCAPE_Cabod
   ata  ildIOCallback callbaincaPROR_WANT_RNULL    e int,a  */
   fimeSd ou03witc fiild'pful
   rrrrrrrrrrrrri    tomcatTSCAPE_Ct OFF anxitanxit[0] TCAPreet the nxita_MY_LAST_Ptwar  ild,ed
     ilde the spful
   rrrrrrrrrrrrrrrrddes,eSoftwareignm s  at  a* Add ati  ilden Tdde.ful
   rrrrrrrrrrrrrrrrOn plat   ta>   pud.9.6dal int S    /**
  SCatii    tomcatSESS_CACHE_OFF = 0x0000;OOSE_MY_LASnt SSL_OPa  */
     et the ssPAPR_E, loMPd. Will banxit[1] Whyd ati  ildedded, ss.
  UnuseeSofof:e removedPRE>lag (0 .APR_PROC_EXITop Bitwie--  the spenmrmi0008d_  ing tmlag (0 .APR_PROC_SIGinal int e--  the spenumbkimeSd      eignm lag (0 .APR_PROC_SIGina_COREie--  the spenumbkimeSd      eignm ,  contd setPPPPPPPPPPPPPPPPPPPPPPPPPP   * @t
  .   re  umply suppord/PRE>lag (0 .SLn a laa   ow How blic stwelaa  .rrOnefof:e removedPRE>lag (0 .APR_WAITve
-- bwackHuntientati  ild  the speddes.lag (0 .APR_NOWAITv--    *   immedi inly-native        ifc final int ame Filename t  ild     tntp_VERStly suppord/PRE>lag (0 .Slength of rP sequenalloD = 1  ild      tomcat-ou03of.UtB Thf *    tia int /FIPS_modetGACong  tic1
     */
 latious bug workarouaa  All incsL_new
ethe  int [] txit, @param filename Filename to save the data
int Sata ow  boolem seal statssUpublic staDettriltwar the spefroth    *  ino   * @nmrmi00lly support OFF a0aemon   *0.1
   non-zero*
     * the speblic st0aemon   ntd setPPPPPPPPPPPPPPPPPPys.
beSL_tia  10.grn Fi* the sp, e fin     */ntd setPPPPPPPPPPPPPPPPPPtioyRetuubli Soegrn Fi.UtB Thf *    tia int /FIPS_modetGACong  tic1
     */
 latious bug workaroudettri be r0aemon   oved in Tomcat 10.1.mrmi0008ia  the spflag (0 .k callbaincaTCAP the spen Tomrmi0008.e removet OFF avig How n Tkimentati the spflag (0 .k    tia int /FIPS_modetGACong  tic1
     */
 latious bug workaroukimeL_new
ethe  int vigovedool);

    /**
     * Get the specified file''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''s stats.
     * @param finfo Where to store the infSackaddration about the file.
     * @param wante desired apr_finfo_t fields, a03204it flag of APR_3117O_ values
     * @param thefile The file to get information about.
     * @return the operation status
     */
    public static native int infoGet(FileInfo finfo, int wanted, long thefile);


    /**
     * Get the specified file's stats.
     * @param wanted The desired apr_finfo_t fields, as a bit flag of APR_FINFO_ values
     * @param thefile The file to get information about.
     * @return FileInfo object.
     */
    public static native FileInfo getInfo(int wanted, long thefile);

}
                                           tomcat-native-1.3.0-src/java/org/apache/tomcat/jni/SSL.java                                         0000664 0001750 0001750 00000073537 14560225303 022046  0                                                                                                    ustar   mark                            mark                                                                                                                                                                                                                   /*
 *  Licensed to the Apache Software Foundation (ASF) under one or more
 *  contributor license agreements.  See the NOTICE file distributed with
 *       *lSackaddrark    @tu iSofMla pubTurkark    @l int SSL_Eative    L_SHUTDOWAPR/N offseERT_CHAa  */
      uc = 6;
    pu
stame Filename tlic .x /
    pubN offse2.x on        * callbpublicUTDose
stame Filename t      *nfo           0x Se abl);

    /*ic grt at a    TSCAPNam ltame Filename ttnd_Nam2 g   = 1ors the Nbal Passwordyte[] b additSackaddral info   sandom sequence i..ic1
     */
 laboolem sedeprec   sandoDostd. Wic1
     */
 latatus cDostd. Wdeprec   sE      a_SERVER_SHUTDOWint S    */
 r   /* Pericomd. Wi Softwar nt Sc1
     */
 latatus c Perd. Wdeprec   sT whi  er la nt Sc1
     */
 laRTI *nt deprec   sT whfamitmpeted count.
  arouEamitmc stat   blic staIf mulc p   addr   ong  filfn Fi*     r_sackaddr_    A.
 (),1t. vlly
      ints    a0rt SSs  pic fi
 f acka
 xt addr   .ic1
     */
 laboole
 xtvedool);

    /**
     * Get the specified file''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''s stats.
     * @param finfo Where to store the infMmapation about the file.
     * @param wanted Th desired apr_finfo_t fields, a05447it flag of APR_F272O_ values
     * @param thefile The file to get information about.
     * @return the operation status
     */
    public static native int infoGet(FileInfo finfo, int wanted, long thefile);


    /**
     * Get the specified file's stats.
     * @param wanted The desired apr_finfo_t fields, as a bit flag of APR_FINFO_ values
     * @param thefile The file to get information about.
     * @return FileInfo object.
     */
    public static native FileInfo getInfo(int wanted, long thefile);

}
                                           tomcat-native-1.3.0-src/java/org/apache/tomcat/jni/SSL.java                                         0000664 0001750 0001750 00000073537 14560225303 022046  0                                                                                                    ustar   mark                            mark                                                                                                                                                                                                                   /*
 *  Licensed to the Apache Software Foundation (ASF) under one or more
 *  contributor license agreements.  See the NOTICE file distributed with
 *       *lMmapark    @tu iSofMla pubTurkark    @l int SSL_Eative    L_SHUTDOWAPR/N offseERT_CHAa  */
      uc = 6;
    pu
stame Filename tlic .x /
    pubN offse2.x on        * callbpublicUTDose
stame Filename t      *nfo           0x Se abl);

    /*ic grt at a    TSCAPNam ltame Filename ttnd_Nam2 g   = 1ors the Nbal Passwordyte[] b additMmapal prec   sMMapaode  staticutnt oneeted count.
     * @param ssl SAPR_MMAPeturn tse-OR of    sMMapaode  static       eeted count.
     * @param ssl SAPR_MMAPe     *link #d in Tomcat 10.1C.9.7. */
   mmap'nt fipsMou03of  de>xistHedname fipstaining random data.ativefi    *   i    an mmaptaining random doff0.1
tiveoff0.1
i    ode availabl;

rle   publicRROR_WANatIOCallback callbs   *tive    *S Mode avaiaining random dalaiJP_t-nuseeSofof:e removedPRE>lag (0 .APR_MMAPeturn ttttttMMapaode  staticutnt onlag (0 .APR_MMAPe     *
    MMapaode  static       y suppord/PRE>lag (0 .Slength of random sequence i     RV9.7manipulammaptaining ra   *   TCAP
  allRV9.7.d mmap'nt fipsL version string ( if t( if tRV9.7manimemoryumapp   y suppoeates random data to filena_new
RV9.7. nativfips  booleoff0.1  boole      int alai  boolem sea
me, int len,
    if ved in Tomcat 10.1Du taticeftware FoundednMMAPIOCallback callbmmap TCAPmmap n Tdu tatice.lag (0 .Slength of random sequence i*/
pndw_mmaptaining ra   *   Du taticed mmap'nt fipsL version string ( if t( if tdu taticmanimemoryumapp   y suppoeates random data to filena_new
du  nativmmap  boolem sea
me, int len,
    if ved in Tomcat 10.1R      */mmap'ntIOCallback callbmm TCAPmmap'nt fipsL version     tia int /FIPS_modetGACong  tic1
     */
 latious bug workaroude     nativmmoved in Tomcat 10.1Moessful
RROR_WANi    ode mmap'nt fipsM nate a
 Foundednoff0.1IOCallback callbmm TCAPmmap'nt fipsL version ndom doff0.1
tiveoff0.1
 na     totaining ra   *   TCAPRROR_WANT_Rntedoff0.1

 FoundedL version string ( if t( if tutnt oneavaiaining eates random data to filena_new
off0.1 nativmm  booleoff0.1a
me, int len,
    if vedool);

    /**
     * Get the specified file'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''s stats.
     * @param finfo Where to store the infGd
   ation about the file.
     * @param wanted  desired apr_finfo_t fields, a10545it flag of APR_F573O_ values
     * @param thefile The file to get information about.
     * @return the operation status
     */
    public static native int infoGet(FileInfo finfo, int wanted, long thefile);


    /**
     * Get the specified file's stats.
     * @param wanted The desired apr_finfo_t fields, as a bit flag of APR_FINFO_ values
     * @param thefile The file to get information about.
     * @return FileInfo object.
     */
    public static native FileInfo getInfo(int wanted, long thefile);

}
                                           tomcat-native-1.3.0-src/java/org/apache/tomcat/jni/SSL.java                                         0000664 0001750 0001750 00000073537 14560225303 022046  0                                                                                                    ustar   mark                            mark                                                                                                                                                                                                                   /*
 *  Licensed to the Apache Software Foundation (ASF) under one or more
 *  contributor license agreements.  See the NOTICE file distributed with
 *       *lGd
   ark    @tu iSofMla pubTurkark    @l int SSL_Eative    L_SHUTDOWAPR/N offseERT_CHAa  */
      uc = 6;
    pu
stame Filename tlic .x /
    pubN offse2.x on        * callbpublicUTDose
stame Filename t      *nfo           0x Se abl);

    /*ic grt at a    TSCAPNam ltame Filename ttnd_Nam2 g   = 1ors the Nbal Passwordyte[] b additGd
   al informamcat 10.1C.9.7. *nd
    publi  */m   xs  at  a     * Addabl;yncen,n   * - dunsafe leghe spong poooh butsn uste:ativr     al sigre     undehtntpine d   y suppor046  versif* callcross- the spef tRVoss-oh but/m  u  a   luINFO_isoid setPas      .sed t pr_ethe_m   x.hlean rpr_oh but_m   x.hlf
    publ2snNfis Foum    d wackHc staticly suppordlr>dlement th : fea CieoolAPR_HAS_foo_SERIALpubldefaticdabl; *

  ful
Rlat   tassword Pntd setPPPPPPPPPPAPR_LOCK_foo.rrOnallAPR_LOCK_DEFAULT  ve ve     taining random dad. WiA 0    d. Wiuence i
  ful
wackHmechanismPas     tione.NT_DH_oid setPPPPPPPPargutInfeblic stalway =beP be abld.EativewackHryptcitbelf   */ntd setPPPPPPPPdetmrmi0e 
  i  blic statiOR_ZEOCallback callbmech TCAPmechanismPuence i*/
pful
OR_WA the spewack,ed
  ny;ionefofe removedPRE>lag (0 . PPPPPPPPPPAPR_LOCK_FCNTLlag (0 . PPPPPPPPPPAPR_LOCK_FLOCKlag (0 . PPPPPPPPPPAPR_LOCK_SYSVSEMlag (0 . PPPPPPPPPPAPR_LOCK_POSIXSEMlag (0 . PPPPPPPPPPAPR_LOCK_PROC_PTHturnlag (0 . PPPPPPPPPPAPR_LOCK_DEFAULT tes rickHod FIPS_modemechanismP Softwar lat   ty suppord/PRE>lag (0 .Slength of rtndom seqfroth    /* enalloD = 1ode m   x.aining ra   *   N  allRV9.7.d m   x.aining rastring ( if tIfastatus ofhe operation wa/
     *
     * @deprecated_new
RV9.7. tatus cad. W   *   ech  boolem sea
me, int len,
    if ved in Tomcat 10.1R -ode  */m   xs       ild  the sptaining random dad. WiA 0    d. Wiuence i
  ful
m   xsmechanismPas     tione.NT_DH_oid setPPPPPPPPPPPPPPargutInfeblic stalway =beP be abld.Eativem   xsryptcitbelf   */ntd setPPPPPPPPPPPPPPdetmrmi0e 
  i  blic statiOR_ZENT_DH_B0   d. Wiblic statiSCAntd setPPPPPPPPPPPPPPs. Wionef  at numb asiAddabl pr_ethe_m   x_RV9.7. ).lag (0 .Slength of random sequen /FIPSWionflag (0 ... verify dept6 * @be    publ na  *ic     ve   ility   v intSLn a public statful
 agrel0maniwackHmechanismPdoeER_CHAas        .t%2snNfin   *   N  allode  stm   x.aining rastring ( if tIfastatus ofhe operation wa/
     *
     * @deprecated_new
R ilddataLtatus cad. W  boolem sea
me, int len,
    if ved in Tomcat 10.1Ac      ful
wackH*/
packagiv stm   x.tIfaful
m   xs veal buty
wacked,  OP_NETSCAPblic staoh but/  */
   pu1
 nasleepHuntientatiwackHbeSL_ta>
     * @EOCallback callbm   xs  l
m   xst a    /* enac      ful
wackL version     tia int /FIPS_modetGACong  tic1
     */
 latious bug workarouwack nativm   xoved in Tomcat 10.1Attempt* enac      ful
wackH*/
packagiv stm   x.tIfaful
m   xs   =al buty SSL_phpbeen ac     d, ss.
ng po    tis)immedi inly-    TAPR_EBUSYn uste:ai lly
     ve/*
ve  ntmcat 1t.ePAPR_STATUS_IS_EBUSY(s)a  RVo    * Addabldetmrmi0elly
     fuubli Get ttrver  numbAPR_EBUSY  f
   ve   ilitytutnsl sEOCallback callbm   xs  l
m   xst a    /* enattempt* ul
wackHac    Hed.WN l int     tia int /FIPS_modetGACong  tic1
     */
 latious bug workaroutrywack nativm   xoved in Tomcat 10.1Reltns  ful
wackH*/
packagiv stm   x.OCallback callbm   xs  l
m   xsfroth    /* enreltns  ful
wack.WN l int     tia int /FIPS_modetGACong  tic1
     */
 latious bug workarouunwack nativm   xoved in Tomcat 10.1De   oys  l
m   xsean freec seimemoryuasiocit eda    TSCAPwack.WN l int  callbm   xs  l
m   xsablde   oyL version     tia int /FIPS_modetGACong  tic1
     */
 latious bug workaroude   oy nativm   xovedool);

    /**
     * Get the specified file'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''s stats.
     * @param finfo Where to store the inf  if ation about the file.
     * @param wanted T desired apr_finfo_t fields, a05557it flag of APR_F473O_ values
     * @param thefile The file to get information about.
     * @return the operation status
     */
    public static native int infoGet(FileInfo finfo, int wanted, long thefile);


    /**
     * Get the specified file's stats.
     * @param wanted The desired apr_finfo_t fields, as a bit flag of APR_FINFO_ values
     * @param thefile The file to get information about.
     * @return FileInfo object.
     */
    public static native FileInfo getInfo(int wanted, long thefile);

}
                                           tomcat-native-1.3.0-src/java/org/apache/tomcat/jni/SSL.java                                         0000664 0001750 0001750 00000073537 14560225303 022046  0                                                                                                    ustar   mark                            mark                                                                                                                                                                                                                   /*
 *  Licensed to the Apache Software Foundation (ASF) under one or more
 *  contributor license agreements.  See the NOTICE file distributed with
 *       *l  if ark    @tu iSofMla pubTurkark    @l int SSL_ERROR_ZERO_RETURN      = 6;
    public ste Nbal Passwordyte[] b addit( if texte dicde>true</cl inforprivPSWi   * @param sboole erial00664 0UIDETS1Lved in Tomcat 10.1APRatus ofis fialize n/OR_WANrivPSWiaram ssl Se if ved in Tomcat 10.1Aude cripc fi
 f ackaeth   mialize n/OR_WANrivPSWiaram status cde cripc fived in Tomcat 10.1Cens  uct    APRde>true</ly suppot%2snNfinaALL: tus ofhnL_SHUTDOWrver  6;
  if arsupport OFF a01 cripc fi
tus ofm   agata in Bgets(byrivPSWi  if (sl Se if ,status cde cripc fia
me, {
me, int su or(tus of+ ": "f+ de cripc fia;
me, int leis.tus of=Se if veme, int leis.01 cripc fi
=cde cripc fiveint } statsUpublic staE_CHOOSEAPRatus ofryptcSHUTDOWee>true</ly suppot%2snNfin    tiatus ofhHUTDOWde>true</ng  tic1
     */
 laarounds  if (a
me, {
me, int     tiatus oveint } statsUpublic staE_CHOOSEAPRade cripc fi
 f ackaee>true</ly suppot%2snNfin    tiade cripc fi
 f ackade>true</ng  tic1
     */
 lat, long.
 De cripc fi(a
me, {
me, int     tiade cripc fiveint } statsUpublic staE_CHOOSEed. WRlat   ta> if ly suppoti    tias r_stGACo_CHOOSEed. WRlat   ta> if   f
ld = 6;abl pr_stGACo_C,      s  plat   talag (0 ... ve   rievava> ino,eSofng pa>
 Gds     * @p()i  yl  rify dep,  contd setPPPPPPf
ldsn       TAPR_FROM_OS_ERROe.NTSL_tiplat   ta>(er h ssPOS2)s  orknontd setPPPPPPer h mechanism    ON_REN g po       *nssword _ZENTDod, l3 022046 ntd setPPPPPPng pooSofsacke Se if pefrothsacke ,s eFO,
rtcv etc!ng  tic1
     */
 latious bug workarouos * @p(); statsUpublic staE_CHOOSEed. WRlat   tasacke Se if  never more.  If thered. Wsacke Se if   f
ld = 6;abl pr_stGACo_C,    g poplat   talag (0 ... ve   rievava> inoeSofng pa>
 Gds    Sacke  * @p()i  yl  rify dep,ntd setPPPPPPean f
ldsn       TAPR_FROM_OS_ERROe.ng  tic1
     */
 latious bug workarounetos * @p(); statsUpublic staR   tias humantutnt     satus cde cribmanipula
 Foundedne if  never mor callbsiouryptcandoL instryptpackaget a_SERVER_ff  never more.  If andoL instSERVER neverBgets(byte[] buf,  int offset, longSERe if (sl Ssiouryptovedool);

    /**
     * Get the specified file'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''s stats.
     * @param finfo Where to store the infSSLCenfation about the file.
     * @param wanted desired apr_finfo_t fields, a10212it flag of APR_F631O_ values
     * @param thefile The file to get information about.
     * @return the operation status
     */
    public static native int infoGet(FileInfo finfo, int wanted, long thefile);


    /**
     * Get the specified file's stats.
     * @param wanted The desired apr_finfo_t fields, as a bit flag of APR_FINFO_ values
     * @param thefile The file to get information about.
     * @return FileInfo object.
     */
    public static native FileInfo getInfo(int wanted, long thefile);

}
                                           tomcat-native-1.3.0-src/java/org/apache/tomcat/jni/SSL.java                                         0000664 0001750 0001750 00000073537 14560225303 022046  0                                                                                                    ustar   mark                            mark                                                                                                                                                                                                                   /*
 *  Licensed to the Apache Software Foundation (ASF) under one or more
 *  contributor license agreements.  See the NOTICE file distributed with
 *  yte[] baram s additSSLCenfal informamcat 10.1C.9.7. */
   rneduONFublic st.ave the len The length of random sequence in bytes
 ndom dalaisiTCAPrneduONFualaisiuence iTile a     a
22bombi000 fi
 f  OP_NETSCAPatlway * :e removedPRE>lag (0 .{@linkPrne#rneduONF_FLAG_CMDLINE}lag (0 .{@linkPrne#rneduONF_FLAG_NT  }lag (0 .{@linkPrne#rneduONF_FLAG_CLIENT}lag (0 .{@linkPrne#rneduONF_FLAG_SERVER}lag (0 .{@linkPrne#rneduONF_FLAG_SHOW_ERROeS}lag (0 .{@linkPrne#rneduONF_FLAG_CERTIFICAT }lag (0 .d/PRE>lag (0 never more.  If andoJion0rt SSs  pic fi
 f aPRROR_WANT_Rnted
  allRV9.7.dntSLn a public srneduONFuClic stlag (0 never morurn <code>true</cIfaful
rneduONFublic stublc st5303be  V9.7.dntSLn anever mor; *
<s href=" ustsar   maode ssl     docs/man1.0.2/ssl/rneduONF_CTX_
  .html">;

    /rneduONF_CTX_
  </a>never mor; *
<s href=" ustsar   maode ssl     docs/man1.0.2/ssl/rneduONF_CTX_set_his ilhtml">;

    /rneduONF_CTX_set_his i</a>never m/
     *
     * @deprecated_new
mak. native se  int alais) len,
                             Freec seiSSsouocong* Add yh    *  i stlag (0 never mor BIO
  ctx
rneduONFublic stueturree.ntSLn anever mor; *
<s href=" ustsar   maode ssl     docs/man1.0.2/ssl/rneduONF_CTX_
  .html">;

    /rneduONF_CTX_rree</a>never m/
     *
     * @deprecated   purree      =ctxoved in Tomcat 10.1Cieoola SL_O        T pHLicduONFublic st.ave the len The length ctx
rneduONFublic stuetuce in bytes
 ndom dd. WiSL_O    ccessful
   rt OFF arver  SL_O    rver .lag (0 never more.  If andoresulcST_Ptwar  eoolbas      twarglng enrneduONF_cmd_rver _is f}lag (0 .ng p.   knAPI)
s f
   */
resulcSing pHee>true</, ssPw wh aalag (0 .0    .
   i  cRoryu
s f
    di**utSet(fipsMor  i  cRoryuccess.lag (0 never morurn <code>true</cIfaful
  eoolfails.ntSLn anever mor; *
<s href=" ustsar   maode ssl     docs/man1.0.2/ssl/rneduONF_cmd.html">;

    /rneduONF_cmd_rver _is f</a>never m/
     *
     * @deprecatedarouR eoo      =ctx,status cd. W  tatus crver ) len,
                             Aseigng pHLice lic stuetu pHLicduONFublic st.ave theillltatlway * @ng pa>etu{@linkP#    y nati  tatus   tatus )}/  */
  tion regap
 *  c nateis Lice lic st.ave the len The length ctx
rneduONFublic stuetuce in bytes
 ndom dctx
rnee lic stuetu seigngT_Rntedgiv stLicduONFublic st.ave the len The ; *
<s href=" ustsar   maode ssl     docs/man1.0.2/ssl/rneduONF_CTX_set_ssl_ctxlhtml">;

    /rneduONF_CTX_set_ssl_ctx</a>never m/
     *
     * @deprecated   pu seign      =ctx,s     =txoved in Tomcat 10.1A   yla SL_O    etu pHLicduONFublic st.ave the len The length ctx
rneduONFublic stuetuce in bytes
 ndom dd. WiSL_O    ccessful
   rt OFF arver  SL_O    rver .lag (0 never more.  If andoresulcST_Ptwarrecatedglng enrneduONF_cmd}@ng plag (0 never morurn <code>true</cIfaful
rneduONFublic stuis glng en0}ntSLn anever mor; *
<s href=" ustsar   maode ssl     docs/man1.0.2/ssl/rneduONF_cmd.html">;

    /rneduONF_cmd</a>never m/
     *
     * @deprecatedarou    y nati =ctx,status cd. W  tatus crver ) len,
                             Fnn  //SL_O    e Sofa
HLicduONFublic st.ave the len The length ctx
rneduONFublic stuetuce in bytesnever more.  If andoresulcST_Ptwarrecatedglng enrneduONF_CTX_rnn  /}@ng plag (0 never mor; *
<s href=" ustsar   maode ssl     docs/man1.0.2/ssl/rneduONF_CTX_set_his ilhtml">;

    /rneduONF_CTX_rnn  /</a>never m/
     *
     * @deprecatedarournn  /      =ctxovedool);

    /**
     * Get the specified file'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''' specified file'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''s stats.
     * @param finfo Where to store the infUseration about the file.
     * @param wanted Th desired apr_finfo_t fields, a12072it flag of APR_F306O_ values
     * @param thefile The file to get information about.
     * @return the operation status
     */
    public static native int infoGet(FileInfo finfo, int wanted, long thefile);


    /**
     * Get the specified file's stats.
     * @param wanted The desired apr_finfo_t fields, as a bit flag of APR_FINFO_ values
     * @param thefile The file to get information about.
     * @return FileInfo object.
     */
    public static native FileInfo getInfo(int wanted, long thefile);

}
                                           tomcat-native-1.3.0-src/java/org/apache/tomcat/jni/SSL.java                                         0000664 0001750 0001750 00000073537 14560225303 022046  0                                                                                                    ustar   mark                            mark                                                                                                                                                                                                                   /*
 *  Licensed to the Apache Software Foundation (ASF) under one or more
 *  contributor license agreements.  See the NOTICE file distributed with
 *       *lUserark    @tu iSofMla pubTurkark    @l int SSL_Eative    L_SHUTDOWAPR/N offseERT_CHAa  */
      uc = 6;
    pu
stame Filename tlic .x /
    pubN offse2.x on        * callbpublicUTDose
stame F